//
//  ViewController.swift
//  Assignment5
//
//  Created by Sheetal Singh on 10/26/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func add_btn(_ sender: UIButton) {
        performSegue(withIdentifier: "addSegue", sender: self)
    }

    @IBAction func list_btn(_ sender: UIButton) {
        
        performSegue(withIdentifier: "listSegue", sender: self)
    }
    
    @IBAction func search_btn(_ sender: UIButton) {
        performSegue(withIdentifier: "searchSegue", sender: self)
    }
    @IBAction func delete_btn(_ sender: UIButton) {
        performSegue(withIdentifier: "deleteSegue", sender: self)
    }
}

