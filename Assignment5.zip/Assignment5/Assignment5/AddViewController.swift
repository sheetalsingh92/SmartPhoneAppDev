//
//  AddViewController.swift
//  Assignment5
//
//  Created by Sheetal Singh on 10/26/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

class AddViewController: UIViewController {

    @IBOutlet weak var item_name: UITextField!
    @IBOutlet weak var item_price: UITextField!
    @IBOutlet weak var item_type: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func add_btn(_ sender: UIButton) {
        
        
        let itemType = ItemType()
        var nameItem = ""
        if let itemName = item_name.text{
            nameItem = itemName
        }
        
        
        var priceItem = 0
        
        if let itemPrice = Int((item_price.text!)) {
            priceItem = itemPrice
        }
        
        
        if let  typeItem = item_type.text{
            itemType.name = typeItem
        }
        
        
        
        let item = Item(itemName:nameItem,itemPrice:priceItem,type:itemType)
        itemType.addItem(item)
        
        main_wishlist.addItem(item)
        
        item_name.text = ""
        item_price.text = ""
        item_type.text = ""
      
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
