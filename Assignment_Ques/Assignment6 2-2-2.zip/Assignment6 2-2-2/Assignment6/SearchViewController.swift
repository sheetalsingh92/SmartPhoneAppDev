//
//  SearchViewController.swift
//  Assignment6
//
//  Created by Sheetal Singh on 11/2/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

var indx:Int = 0


class SearchViewController: UIViewController, detailViewControllerDelegate {
    
    @IBOutlet weak var item_name: UITextField!
    
    @IBOutlet weak var item_price: UITextField!
    
    @IBOutlet weak var item_type: UITextField!
    
    @IBOutlet weak var image: UIImageView!
    
    //var item: Item?
    func selectedItem(t :Int){
      
   
        indx = t
        //print("\(t.itemName) is displayed in search view controller")
        
        //itemName = t.itemName
//        item_name.text = t.itemName
//        item_price.text = String(describing: t.itemPrice)
//        item_type.text = t.type.name
        
        //print("\(itemName) hi there")
       
        
    }
        
//        item_name.text = detailItem.itemName
//        item_price.text  = String(describing: detailItem.itemPrice)
//        item_type.text = detailItem.type.name
//    }
    
    
    
    var wishlist_arr:[Item] = w.arr_wishlist

    override func viewWillAppear(_ animated: Bool) {
        //print("\(item?.itemName)")
        item_name.text = wishlist_arr[indx].itemName
        item_price.text = String(wishlist_arr[indx].itemPrice)
        item_type.text = wishlist_arr[indx].type.name
        image.image = images[indx]
//        item_name.text = 
//        print("\(itemName) last print")
//        item_name.text = itemName
    
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
