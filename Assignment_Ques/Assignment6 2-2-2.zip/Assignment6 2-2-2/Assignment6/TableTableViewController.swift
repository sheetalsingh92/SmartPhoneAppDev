    //
//  TableTableViewController.swift
//  Assignment6
//
//  Created by Sheetal Singh on 11/5/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

var w = Wishlist()

var images = [UIImage(named:"dice6"),
              UIImage(named:"Icon-40"),
              UIImage(named:"newbackground"),
              UIImage(named:"AppIcon29x29-1"),
              UIImage(named:"AppIcon29x29-2"),
              UIImage(named:"AppIcon29x29-3"),
              UIImage(named:"AppIcon29x29"),
              UIImage(named:"AppIcon76x76")
]

protocol detailViewControllerDelegate{
    
    func selectedItem(t :Int)
}

class TableTableViewController: UITableViewController, ViewControllerDelegate {
    
    let searchController = UISearchController(searchResultsController: nil)
    
        var detaildelegate: detailViewControllerDelegate?
    
    var filteredlist = [Item]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let dtlVC = SearchViewController()
        self.detaildelegate = dtlVC
        
        searchController.searchResultsUpdater = self as? UISearchResultsUpdating
        searchController.obscuresBackgroundDuringPresentation = false
       navigationItem.searchController = searchController
        definesPresentationContext = true

        
    }
    
    
    func isFiltering() -> Bool {
        return searchController.isActive && !searchBarIsEmpty()
    }
    
    override func viewWillAppear(_ animated: Bool) {
      tableView.reloadData()
    }
    
    
    func searchBarIsEmpty() -> Bool {
        // Returns true if the text is empty or nil
        return searchController.searchBar.text?.isEmpty ?? true
    }
    
    func filterContentForSearchText(_ searchText: String, scope: String = "All") {
        filteredlist = w.arr_wishlist.filter({( item : Item) -> Bool in
            return item.itemName.lowercased().contains(searchText.lowercased())
        })
        
        tableView.reloadData()
    }
    
  
        
        

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source



    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
       
        if isFiltering() {
            return filteredlist.count
        }
        
        return w.arr_wishlist.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let item: Item
        if isFiltering() {
            item = filteredlist[indexPath.row]
            cell.imageView?.image = nil
        } else {
            item = w.arr_wishlist[indexPath.row]
            let newimage = images[indexPath.row]
            cell.imageView?.image = newimage
        }
        
//        let item : Item = w.arr_wishlist[indexPath.row]
        
      
        
        cell.textLabel?.text = item.itemName
        
        
        return cell;
    
    
    
    }
    
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            
            // remove the item from the data model
            w.arr_wishlist.remove(at: indexPath.row)
            
            // delete the table view row
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        } else if editingStyle == .insert {
            // Not used in our example, but if you were adding a new row, this is where you would do it.
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let detailVC = storyBoard.instantiateViewController(withIdentifier: "SearchViewController")
        
        let t = indexPath.row
        //print("\(t.itemName) is displayed in Tableview")
        detaildelegate?.selectedItem(t: t)
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
    
    func newWishList(item: Item?) {
        if let item = item{
            w.addItem(item)
            for t in w.arr_wishlist{
                print(t.itemName)
            }
            print("new item is \(item.itemName)")
        }
        
    }
 
    @IBAction func add_btn(_ sender: UIBarButtonItem) {
       
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "AddViewController")
        navigationController?.pushViewController(controller,
                                                 animated: true)
        
    }
 
}

extension TableTableViewController: UISearchResultsUpdating {
    // MARK: - UISearchResultsUpdating Delegate
    func updateSearchResults(for searchController: UISearchController) {
       filterContentForSearchText(searchController.searchBar.text!)
    }
}
