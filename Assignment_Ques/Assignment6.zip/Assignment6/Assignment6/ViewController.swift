//
//  ViewController.swift
//  Assignment6
//
//  Created by Sheetal Singh on 11/2/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

class ViewController: UITableViewController, ViewControllerDelegate{

    @IBOutlet var list_tableView: UITableView!

    
    let wishlist = Wishlist()
    
    func showAlert(message : String){
        let alert = UIAlertView()
        alert.title = "Alert"
        alert.message = message
        alert.addButton(withTitle: "Ok")
        alert.show()
    }
    
    
    func newWishList(item: Item?) {
        if let item = item{
            wishlist.addItem(item)
            for t in wishlist.arr_wishlist{
                print(t.itemName)
            }
            print("new item is \(item.itemName)")
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView(frame: CGRect.zero)
    }
    
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func add(_ sender: UIBarButtonItem) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "AddViewController")
        navigationController?.pushViewController(controller,
                                                 animated: true)
    }

    @IBAction func search(_ sender: UIBarButtonItem) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "SearchViewController")
        navigationController?.pushViewController(controller,
                                                 animated: true)
    }
   

    
}


extension ViewController {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) ->Int {
        <#code#>
    }
}



