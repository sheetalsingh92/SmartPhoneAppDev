//
//  ItemType.swift
//  Assignment6
//
//  Created by Sheetal Singh on 11/2/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import Foundation

class ItemType {
    var name: String = ""
    var arr_item: [Item] = []
    
    
    func addItem(_ item:Item){
        
        arr_item.append(item)
        
    }
    
    
    
}
  
