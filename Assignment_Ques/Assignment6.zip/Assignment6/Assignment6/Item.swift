//
//  Item.swift
//  Assignment6
//
//  Created by Sheetal Singh on 11/2/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import Foundation

class Item{
    
    var itemName: String
    var itemPrice : Int
    var type : ItemType
    
    init(itemName:String, itemPrice: Int, type: ItemType){
        
        self.itemName = itemName
        self.itemPrice = itemPrice
        self.type = type
        
        
        
    }
    
}
