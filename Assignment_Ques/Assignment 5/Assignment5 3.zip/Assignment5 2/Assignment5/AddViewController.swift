//
//  AddViewController.swift
//  Assignment5
//
//  Created by Sheetal Singh on 10/26/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

protocol ViewControllerDelegate: class {
    
    func newWishList(item:Item?)
    
}

class AddViewController: UIViewController {

    var delegate  : ViewControllerDelegate?
    @IBOutlet weak var item_name: UITextField!
    @IBOutlet weak var item_price: UITextField!
    @IBOutlet weak var item_type: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showAlert(message : String){
        let alert = UIAlertView()
        alert.title = "Alert"
        alert.message = message
        alert.addButton(withTitle: "Ok")
        alert.show()
    }
    
    
    @IBAction func add_nav_btn(_ sender: UIBarButtonItem) {
        
        do
        {     let regex_num = try NSRegularExpression(pattern: ".*[^0-9.].*", options: [])
            let regex = try NSRegularExpression(pattern: ".*[^A-Za-z ].*", options: [])
            if (item_name.text == ""){
                showAlert(message: "Please enter ItemName")
            }
                
                
                
            else  if(regex_num.firstMatch(in: item_price.text!, options: [], range: NSMakeRange(0, (item_price.text?.characters.count)!)) != nil){
                showAlert(message: "Enter numbers for price")
            }
                
            else if((regex.firstMatch(in: item_type.text!, options: [], range: NSMakeRange(0, (item_type.text?.characters.count)!)) != nil) || (item_type.text == "")){
                showAlert(message: "Please enter string for ItemType")
                
            }
                
            else{
                
                let itemType = ItemType()
                var nameItem = ""
                if let itemName = item_name.text{
                    nameItem = itemName
                }
                
                
                var priceItem = 0
                
                if let itemPrice = Int((item_price.text!)) {
                    priceItem = itemPrice
                }
                
                
                if let  typeItem = item_type.text{
                    itemType.name = typeItem
                }
                
                
                
                let item = Item(itemName:nameItem,itemPrice:priceItem,type:itemType)
                itemType.addItem(item)
                
                delegate?.newWishList(item: item)
                
                item_name.text = ""
                item_price.text = ""
                item_type.text = ""
            }
        }
        catch{
            
        }
    }
    
    @IBAction func cancel_btn(_ sender: UIBarButtonItem) {
          dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
