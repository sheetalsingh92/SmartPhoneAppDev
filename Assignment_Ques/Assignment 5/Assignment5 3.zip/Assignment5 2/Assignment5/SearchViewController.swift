//
//  SearchViewController.swift
//  Assignment5
//
//  Created by Sheetal Singh on 10/26/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController {

    var wishlist : [Item] = []
   
    @IBOutlet weak var item_name: UITextField!
   
    @IBOutlet weak var text_searchView: UITextView!
    
    func showAlert(message : String){
        let alert = UIAlertView()
        alert.title = "Alert"
        alert.message = message
        alert.addButton(withTitle: "Ok")
        alert.show()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func search_btn(_ sender: UIButton) {
        text_searchView.text = ""
        if (item_name.text == ""){
            showAlert(message: "Please enter Item Name")
        }
            
        else{
            
            if( wishlist.isEmpty)
            {
                showAlert(message: "wishlist is empty");
                item_name.text = ""
                text_searchView.text = ""
            }
            else
            {
                
                var xAppears = false
                for item in wishlist{
                    if(item_name.text == item.itemName){
                        xAppears = true
                        text_searchView.text = text_searchView.text + "\n" + "Itemname:" + item.itemName + " " + "ItemPrice:" + String(item.itemPrice) +  " " + "ItemType:" + item.type.name
                        
                    }
                }
                if (!(xAppears))
                {
                    showAlert(message:"The item is not found in wishlist");
                    item_name.text = ""
                    text_searchView.text = ""
                }
                
            }
            
        }
        
        
    }

    @IBAction func back_btn(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
