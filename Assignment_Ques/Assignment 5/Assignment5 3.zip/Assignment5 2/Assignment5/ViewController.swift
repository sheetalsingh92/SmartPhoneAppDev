//
//  ViewController.swift
//  Assignment5
//
//  Created by Sheetal Singh on 10/26/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

class ViewController: UIViewController, ViewControllerDelegate {
    
    let wishlist = Wishlist()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? AddViewController {
            destination.delegate = self
        }
        
        if let destination = segue.destination as? ListViewController {
            destination.wishlist = wishlist.arr_wishlist
        }
        
        if let destination = segue.destination as? SearchViewController {
            destination.wishlist = wishlist.arr_wishlist
        }
    }
    
    
    
    
    func newWishList(item: Item?) {
        if let item = item{
            wishlist.addItem(item)
            for t in wishlist.arr_wishlist{
                print(t.itemName)
            }
            print("new item is \(item.itemName)")
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func add_btn(_ sender: UIButton) {
        performSegue(withIdentifier: "addSegue", sender: nil)
    }

   
    @IBAction func list_btn(_ sender: UIButton) {
        
        
        
      performSegue(withIdentifier: "listSegue", sender: nil)
        //present(listvc, animated: true, completion: nil)
        
        
    }
    
    
    @IBAction func search_btn(_ sender: UIButton) {
        performSegue(withIdentifier: "searchSegue", sender: nil)
    }
    @IBAction func delete_btn(_ sender: UIButton) {
        performSegue(withIdentifier: "deleteSegue", sender: self)
    }
}

