//
//  AddViewController.swift
//  Assignment8
//
//  Created by Sheetal Singh on 11/25/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit
import CoreData

class AddViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var managedObjectContext: NSManagedObjectContext!
     var imagePicker = UIImagePickerController()
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var itemname: UITextField!
    
    @IBOutlet weak var itemtype: UITextField!
    
    @IBOutlet weak var itemprice: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func addImage(_ sender: UIButton) {
        
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            print("Button capture")
            
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum;
            imagePicker.allowsEditing = false
            
            self.present(imagePicker, animated: true, completion: nil)
        }
        
    }
    
    
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var selectedImageFromPicker = info[UIImagePickerControllerOriginalImage] as! UIImage?
        if let selectedImage = selectedImageFromPicker {
            DispatchQueue.main.async {
                self.imageView.image = selectedImage
                self.imageView.setNeedsDisplay()
            }
            
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func add_btn(_ sender: UIButton) {
        
        let item = Item(context: managedObjectContext)
        item.itemname = itemname.text;
        item.itemprice = Int64(itemprice.text!)!;
        item.itemtype?.name = itemtype.text;
        item.itemimage = NSData(data: UIImageJPEGRepresentation((imageView.image)!, 0.3)!) as Data
        
        do{
            try self.managedObjectContext.save()
            print(item.itemimage)
            
        }
        catch{
            print("Could not save data \(error.localizedDescription)")
        }
    }
    
    
}
