//
//  AddViewController.swift
//  Assignment8
//
//  Created by Sheetal Singh on 11/25/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit
import CoreData

class AddViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var managedObjectContext: NSManagedObjectContext!
     var imagePicker = UIImagePickerController()
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var itemname: UITextField!
    
    @IBOutlet weak var itemtype: UITextField!
    
    @IBOutlet weak var itemprice: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func addImage(_ sender: UIButton) {
        
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            print("Button capture")
            
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum;
            imagePicker.allowsEditing = false
            
            self.present(imagePicker, animated: true, completion: nil)
        }
        
    }
    
    
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var selectedImageFromPicker = info[UIImagePickerControllerOriginalImage] as! UIImage?
        if let selectedImage = selectedImageFromPicker {
            DispatchQueue.main.async {
                self.imageView.image = selectedImage
                self.imageView.setNeedsDisplay()
            }
            
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func showAlert(message : String){
        let alert = UIAlertView()
        alert.title = "Alert"
        alert.message = message
        alert.addButton(withTitle: "Ok")
        alert.show()
    }
    
    @IBAction func add_btn(_ sender: UIButton) {
        do
        {
            let regex_num = try NSRegularExpression(pattern: ".*[^0-9.].*", options: [])
            let regex = try NSRegularExpression(pattern: ".*[^A-Za-z ].*", options: [])
            if (itemname.text == ""){
                showAlert(message: "Please enter ItemName")
            }
                
                
                
            else  if(regex_num.firstMatch(in: itemprice.text!, options: [], range: NSMakeRange(0, (itemprice.text?.characters.count)!)) != nil){
                showAlert(message: "Enter numbers for price")
            }
                
            else if((regex.firstMatch(in: itemtype.text!, options: [], range: NSMakeRange(0, (itemtype.text?.characters.count)!)) != nil) || (itemtype.text == "")){
                showAlert(message: "Please enter string for ItemType")
                
            }else if(imageView.image == nil){
                showAlert(message: "Please select an image")
            }
                
            else{
                let item = Item(context: managedObjectContext)
               let itemType = ItemType(context: managedObjectContext)
                var nameItem = ""
                if let itemName = itemname.text{
                    nameItem = itemName
                }
                var priceItem = 0
                
                if let itemPrice = Int((itemprice.text!)) {
                    priceItem = itemPrice
                }
                var item_type = ""
                if let  typeItem = itemtype.text{
                    item_type = typeItem
                }
//                var img:UIImage? = nil
//                if let image = imageView.image{
//                    img = image
//                }
                
               

        item.itemname = nameItem
                item.itemprice = Int64(priceItem);
                item.itemtype = itemType
      item.itemtype?.name = item_type
        item.itemimage = NSData(data: UIImageJPEGRepresentation((imageView.image)!, 0.3)!) as Data
               
        do{
            try self.managedObjectContext.save()
         
            
        }
        catch{
            print("Could not save data \(error.localizedDescription)")
        }
    }
        }
        catch{
            
        }
    }
    
}
