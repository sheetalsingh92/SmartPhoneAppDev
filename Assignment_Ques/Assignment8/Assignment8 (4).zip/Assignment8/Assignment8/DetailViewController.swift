//
//  DetailViewController.swift
//  Assignment8
//
//  Created by Sheetal Singh on 11/25/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var itemname: UITextField!
    
    @IBOutlet weak var itemtype: UITextField!
    @IBOutlet weak var itemprice: UITextField!
    @IBOutlet weak var image: UIImageView!
    
    func configureView() {
        // Update the user interface for the detail item.
        if let detail = detailItem {
            if let itemname = itemname {
                itemname.text = detail.itemname
            }
            
            if let itemprice = itemprice{
                itemprice.text = String( detail.itemprice)
                print("\(itemprice.text) this is item price")
            }
            
            if let itemtype = itemtype{
                itemtype.text = detail.itemtype?.name
            }
            
            if let imageview = image{
                imageview.image = UIImage(data: detail.itemimage as! Data)
            }

        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var detailItem: Item? {
        didSet {
            // Update the view.
            configureView()
        }
    }


}

