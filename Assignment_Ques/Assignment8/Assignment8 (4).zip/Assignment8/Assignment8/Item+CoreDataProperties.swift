//
//  Item+CoreDataProperties.swift
//  Assignment8
//
//  Created by Sheetal Singh on 11/25/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//
//

import Foundation
import CoreData


extension Item {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Item> {
        return NSFetchRequest<Item>(entityName: "Item")
    }

    public var itemname: String?
    public var itemimage: NSData?
    public var itemprice: Int64
    public var itemtype: ItemType?
    public var wishlist: Wishlist?

}
