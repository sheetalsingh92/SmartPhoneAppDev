
import Foundation

class Item{
    
    var itemName: String
    var itemPrice : Int
    var type : ItemType
    
    init(itemName:String, itemPrice: Int, type: ItemType){
        
        self.itemName = itemName
        self.itemPrice = itemPrice
        self.type = type
        
        
        
    }
    
}
