//
//  AddViewController.swift
//  Assignment7
//
//  Created by Sheetal Singh on 11/9/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

protocol ViewControllerDelegate: class {
    
    func newWishList(item:Item?)
    
}

class AddViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
     var delegate  : ViewControllerDelegate?

    @IBOutlet weak var add_item: UITextField!
    
    @IBOutlet weak var price_item: UITextField!
    
    @IBOutlet weak var type_item: UITextField!
    
    @IBOutlet weak var imageView: UIImageView!
    
    var imagePicker = UIImagePickerController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showAlert(message : String){
        let alert = UIAlertView()
        alert.title = "Alert"
        alert.message = message
        alert.addButton(withTitle: "Ok")
        alert.show()
    }
    
    
    @IBAction func btnClicked(_ sender: UIButton) {
        
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            print("Button capture")
            
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum;
            imagePicker.allowsEditing = false
            
            self.present(imagePicker, animated: true, completion: nil)
        }
        //imageView.setNeedsDisplay()
        
        
    }
    
    
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var selectedImageFromPicker = info[UIImagePickerControllerOriginalImage] as! UIImage?
            if let selectedImage = selectedImageFromPicker {
                DispatchQueue.main.async {
                    self.imageView.image = selectedImage
                    self.imageView.setNeedsDisplay()
                }
                
            }
        
        dismiss(animated: true, completion: nil)
    }
   
    

    @IBAction func add_btn(_ sender: UIButton) {
        
        do
        {
            let regex_num = try NSRegularExpression(pattern: ".*[^0-9.].*", options: [])
            let regex = try NSRegularExpression(pattern: ".*[^A-Za-z ].*", options: [])
            if (add_item.text == ""){
                showAlert(message: "Please enter ItemName")
            }
                
                
                
            else  if(regex_num.firstMatch(in: price_item.text!, options: [], range: NSMakeRange(0, (price_item.text?.characters.count)!)) != nil){
                showAlert(message: "Enter numbers for price")
            }
                
            else if((regex.firstMatch(in: type_item.text!, options: [], range: NSMakeRange(0, (type_item.text?.characters.count)!)) != nil) || (type_item.text == "")){
                showAlert(message: "Please enter string for ItemType")
                
            }else if(imageView.image == nil){
                showAlert(message: "Please select an image")
            }
                
            else{
                
                let itemType = ItemType()
                var nameItem = ""
                if let itemName = add_item.text{
                    nameItem = itemName
                }
                
                
                var priceItem = 0
                
                if let itemPrice = Int((price_item.text!)) {
                    priceItem = itemPrice
                }
                
                
                if let  typeItem = type_item.text{
                    itemType.name = typeItem
                }
                
                var img:UIImage? = nil
                if let image = imageView.image{
                    img = image
                }
                
                
                
                let item = Item(itemName:nameItem,itemPrice:priceItem,type:itemType,image:img!)
                itemType.addItem(item)
                if(w.arr_wishlist.isEmpty){
                    delegate?.newWishList(item: item)
                }else{
                    for i in w.arr_wishlist{
                        if(add_item.text == i.itemName ){
                            showAlert(message: "Item already exists!")
                            break
                        }else{
                            delegate?.newWishList(item: item)
                            break
                        }
                    }
                }
                
                
                add_item.text = ""
                price_item.text = ""
                type_item.text = ""
                imageView.image = nil
            }
        }
        catch{
            
        }
    }
   

    }



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
