//
//  MasterViewController.swift
//  Assignment7
//
//  Created by Sheetal Singh on 11/9/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

var w = Wishlist()


class MasterViewController: UITableViewController, ViewControllerDelegate {

    var searchController = UISearchController(searchResultsController: nil)
    var detailViewController: DetailViewController? = nil
    var objects = [Any]()
   // var image:UIImage? = nil

    //@IBOutlet weak var imageView: UITableViewCell!
    var filteredlist = [Item]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        navigationItem.leftBarButtonItem = editButtonItem

//        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(insertNewObject(_:)))
//        navigationItem.rightBarButtonItem = addButton
//        if let split = splitViewController {
//            let controllers = split.viewControllers
//            detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
       
        searchController.searchResultsUpdater = self as? UISearchResultsUpdating
        searchController.obscuresBackgroundDuringPresentation = false
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }

    func searchBarIsEmpty() -> Bool {
        // Returns true if the text is empty or nil
        return searchController.searchBar.text?.isEmpty ?? true
    }
    
    func isFiltering() -> Bool {
        return searchController.isActive && !searchBarIsEmpty()
    }
    
    
    
    func filterContentForSearchText(_ searchText: String, scope: String = "All") {
        filteredlist = w.arr_wishlist.filter({( item : Item) -> Bool in
            return item.itemName.lowercased().contains(searchText.lowercased())
        })
        
        tableView.reloadData()
    }
    override func viewWillAppear(_ animated: Bool) {
       tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func insertNewObject(_ sender: Any) {
        objects.insert(NSDate(), at: 0)
        let indexPath = IndexPath(row: 0, section: 0)
        tableView.insertRows(at: [indexPath], with: .automatic)
    }
    
    
    func newWishList(item: Item?) {
        if let item = item{
            w.addItem(item)
            for t in w.arr_wishlist{
                print(t.itemName)
            }
            print("new item is \(item.itemName)")
        }
        
    }
    
    
    @IBAction func add_btn(_ sender: UIBarButtonItem) {
          performSegue(withIdentifier: "addSegue", sender: nil)
        
    }

    // MARK: - Segues

   
    // MARK: - Table View

   

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFiltering(){
            return filteredlist.count
        }
        return w.arr_wishlist.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let item:Item
        
        
        if isFiltering(){
            item = filteredlist[indexPath.row]
            var count = 0;
            cell.textLabel?.text = item.itemName
            var ind = 0
            for i in w.arr_wishlist{
                if(i.itemName == searchController.searchBar.text!){
                    ind = count
            }
                count = count + 1
            }
            cell.imageView?.image = item.image
            
        }
            else{
                
                item = w.arr_wishlist[indexPath.row]
                cell.textLabel?.text = item.itemName
                cell.imageView?.image = item.image
            
            }
        return cell;
        
    }

    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            w.arr_wishlist.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let destination = segue.destination as? AddViewController {
            destination.delegate = self
        }
        
        if segue.identifier == "showDetail" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                if isFiltering(){
                    let object = filteredlist[indexPath.row]
                    controller.detailitem = object
                    
                }
                    
                else{
                     let obj = w.arr_wishlist[indexPath.row]
                    controller.detailitem = obj
                    
                    
                }
                
                
                
                
                controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
                
                
            }
        }



}
    
}

extension MasterViewController: UISearchResultsUpdating {
    // MARK: - UISearchResultsUpdating Delegate
    func updateSearchResults(for searchController: UISearchController) {
        filterContentForSearchText(searchController.searchBar.text!)
    }
}

