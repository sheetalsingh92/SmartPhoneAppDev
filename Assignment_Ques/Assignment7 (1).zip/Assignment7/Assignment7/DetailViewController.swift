//
//  DetailViewController.swift
//  Assignment7
//
//  Created by Sheetal Singh on 11/9/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    
    @IBOutlet weak var item_name: UITextField!


    @IBOutlet weak var item_price: UITextField!
    
    
    @IBOutlet weak var item_type: UITextField!
    
    @IBOutlet weak var image: UIImageView!
    
    
    func configureView() {
        // Update the user interface for the detail item.
        
        if let x = detailitem{
            if let label = item_name {
                label.text = x.itemName
                print("\(label.text)")
            }
            if let itemprice = item_price{
                itemprice.text = String( x.itemPrice)
                print("\(itemprice.text) this is item price")
            }
            
            if let itemtype = item_type{
                itemtype.text = x.type.name
            }
            
            if let imageview = image{
                imageview.image = x.image
            }
        }
        
        
    
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var detailitem: Item? {
        didSet {
            // Update the view.
            configureView()
        }
    }
    
    var imageindex: Int = 0{
        didSet{
            configureView()
        }
    }


}

