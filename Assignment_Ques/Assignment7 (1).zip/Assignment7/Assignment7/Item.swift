
import Foundation
import UIKit

class Item{
    
    var itemName: String
    var itemPrice : Int
    var type : ItemType
    var image : UIImage
    
    init(itemName:String, itemPrice: Int, type: ItemType, image: UIImage){
        
        self.itemName = itemName
        self.itemPrice = itemPrice
        self.type = type
        self.image = image
    }
}
