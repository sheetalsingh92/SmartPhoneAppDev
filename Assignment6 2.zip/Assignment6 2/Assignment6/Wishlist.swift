//
//  Wishlist.swift
//  Assignment6
//
//  Created by Sheetal Singh on 11/2/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import Foundation


class Wishlist{
    var arr_wishlist: [Item] = []
    
    
    func addItem(_ t:Item)
    {
        
        arr_wishlist.append(t)
        
}

}
