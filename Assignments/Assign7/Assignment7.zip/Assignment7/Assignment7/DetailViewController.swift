//
//  DetailViewController.swift
//  Assignment7
//
//  Created by Sheetal Singh on 11/9/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    
    @IBOutlet weak var item_name: UITextField!


    @IBOutlet weak var item_price: UITextField!
    
    @IBOutlet weak var item_type: UITextField!
    
    @IBOutlet weak var image: UIImageView!
    
    
    func configureView() {
        // Update the user interface for the detail item.
       if let item = detailitem {
//        if let itemname = item_name{
//                itemname.text = item.itemName
//        }
       // print("xx \(item.itemPrice)")
    
        var x = ""
        if let itemprice = item.itemPrice{
            if let itemprice = String(itemprice){
                x = itemprice
        }
        
        }
       
//
//        if let itemtype = item_type{
//                itemtype.text = item.type.name
//        }````
        
        }
    
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var detailitem: Item? {
        didSet {
            // Update the view.
            configureView()
        }
    }


}

