//
//  MasterViewController.swift
//  Assignment7
//
//  Created by Sheetal Singh on 11/9/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

var w = Wishlist()

class MasterViewController: UITableViewController, ViewControllerDelegate {

    var detailViewController: DetailViewController? = nil
    var objects = [Any]()

    

    @IBOutlet weak var add_btn: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        navigationItem.leftBarButtonItem = editButtonItem

//        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(insertNewObject(_:)))
//        navigationItem.rightBarButtonItem = addButton
//        if let split = splitViewController {
//            let controllers = split.viewControllers
//            detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
       
    }

    override func viewWillAppear(_ animated: Bool) {
       tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func insertNewObject(_ sender: Any) {
        objects.insert(NSDate(), at: 0)
        let indexPath = IndexPath(row: 0, section: 0)
        tableView.insertRows(at: [indexPath], with: .automatic)
    }
    
    
    func newWishList(item: Item?) {
        if let item = item{
            w.addItem(item)
            for t in w.arr_wishlist{
                print(t.itemName)
            }
            print("new item is \(item.itemName)")
        }
        
    }
    
    
    @IBAction func add_btn(_ sender: UIBarButtonItem) {
          performSegue(withIdentifier: "addSegue", sender: nil)
        
    }

    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let destination = segue.destination as? AddViewController {
            destination.delegate = self
        }
        
        if segue.identifier == "showDetail" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let object = w.arr_wishlist[indexPath.row]
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.detailitem = object
                controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }

    // MARK: - Table View

   

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return w.arr_wishlist.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let item:Item
        item = w.arr_wishlist[indexPath.row]
        cell.textLabel?.text = item.itemName
     
        return cell;
        
    }

    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            w.arr_wishlist.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }


}

