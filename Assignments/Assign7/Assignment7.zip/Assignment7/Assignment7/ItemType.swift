//
//  ItemType.swift
//  Assignment7
//
//  Created by Sheetal Singh on 11/9/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import Foundation

class ItemType {
    var name: String = ""
    var arr_item: [Item] = []
    
    
    func addItem(_ item:Item){
        
        arr_item.append(item)
        
    }
    
    
    
}
  
