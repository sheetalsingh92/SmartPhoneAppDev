//
//  Item+CoreDataClass.swift
//  Assignment8
//
//  Created by Sheetal Singh on 11/25/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Item)
public class Item: NSManagedObject {

}
