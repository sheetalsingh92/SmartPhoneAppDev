//
//  Wishlist.swift
//  BuyApp
//
//  Created by Sheetal Singh on 10/14/17.
//  Copyright © 2017 NEU. All rights reserved.
//

import Foundation


class Wishlist{
    var arr_wishlist: [Item] = []
    
    
    func addItem(t:Item)
{
    
    print("Enter items in wishlist")
    print("Enter name of the item")
    let item_name = readLine();
    var xAppears = false
    
    for t in store.arr_item{
    if(item_name == t.itemName){
        
        xAppears = true
        
        main_wishlist.arr_wishlist.append(t)
        
        }
    }
    
    if xAppears {
      print("Item \(item_name) is added successfully to wishlist")
       
    }
    
        
    else{
    print("Item not found in store")
      
    }
        
        
 }
   

    
    func listItem()
    {
        if( main_wishlist.arr_wishlist.isEmpty)
        {
            print("wishlist is empty")
        }
        else
        {
            print("List of items in wishlist")
            for item in main_wishlist.arr_wishlist{
                print(item.itemName, item.itemPrice, item.type.name)
            }
        }
    }
    
    
    func searchItem (item:Item)
    {
        if( main_wishlist.arr_wishlist.isEmpty)
        {
            print("wishlist is empty")
        }
        else
        {
            print("Search for item in wish list")
            print("Enter name of the item")
            let item_name = readLine()
            var xAppears = false
            for item in main_wishlist.arr_wishlist{
                if(item_name == item.itemName){
                    xAppears = true
                    print(item.itemName, item.itemPrice, item.type.name)
                    
                }
            }
    if (!(xAppears))
      {
                    print("The item is not found in wishlist");
                }
                
            }
        }

 
    
    func deleteItem(item:Item)
    {
        if( main_wishlist.arr_wishlist.isEmpty)
        {
            print("wishlist is empty")
        }
        else
        {
            print("Delete Item from wishlist")
            
            print("Enter name of the item")
            let item_name = readLine();
            
            var counter = 0;
            var xAppears = false
            for item in main_wishlist.arr_wishlist{
                if(item_name == item.itemName){
                    xAppears = true
                    main_wishlist.arr_wishlist.removeAtIndex(counter)
                    print("Item deleted successfully")
                    break
                }
                    
    
                counter = counter + 1
                
            }
            
            if (!(xAppears))
            {
                print("The item is not found in wishlist");
            }
            
        }

    }

}