//
//  Store.swift
//  BuyApp
//
//  Created by Sheetal Singh on 10/13/17.
//  Copyright © 2017 NEU. All rights reserved.
//

import Foundation



class Store {
    
    var arr_item: [Item] = []
    
    func addItem(item:Item){
        
        arr_item.append(item)
        
        
        if(arr_item.isEmpty){
            print("Its empty")
        }
}
}