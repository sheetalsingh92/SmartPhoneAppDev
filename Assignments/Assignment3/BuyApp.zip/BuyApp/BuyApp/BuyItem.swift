//
//  BuyItem.swift
//  BuyApp
//
//  Created by Sheetal Singh on 10/12/17.
//  Copyright © 2017 NEU. All rights reserved.
//

import Foundation




class Item{
    
    var image : String
    var itemDescription : String
    var itemName: String
    var itemPrice : Int
    
    init(image: String, itemDescription: String, itemName: String, itemPrice: Int ){
        
        self.image = image
        self.itemDescription = itemDescription
        self.itemName = itemName
        self.itemPrice = itemPrice
    }
    
    
}

class Store {
    
    var address : String
    var name : String
    var phone : String
    
    init(address: String, name: String, phone: String){
        self.address = address
        self.name = name
        self.phone = phone
    }
    
}

class ItemType {
    var name: String
    
    init(name: String){
        self.name = name
    }
    
    
    func add(Item t : Item){
        
        
        
    }
    
}
