//
//  ViewController.swift
//  Assignment5
//
//  Created by Sheetal Singh on 10/26/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit

class ViewController: UIViewController, ViewControllerDelegate, deleteViewControllerDelegate {
    
    @IBOutlet weak var addConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var listConstraint: NSLayoutConstraint!

    @IBOutlet weak var searchConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var deleteConstraint: NSLayoutConstraint!
    let wishlist = Wishlist()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? AddViewController {
            destination.delegate = self
        }
        
        if let destination = segue.destination as? ListViewController {
            destination.wishlist = wishlist.arr_wishlist
        }
        
        if let destination = segue.destination as? SearchViewController {
            destination.wishlist = wishlist.arr_wishlist
        }
        
        if let destination = segue.destination as? DeleteViewController {
            destination.wishlist = wishlist.arr_wishlist
            destination.delegate = self
        }
    }
    
    func showAlert(message : String){
        let alert = UIAlertView()
        alert.title = "Alert"
        alert.message = message
        alert.addButton(withTitle: "Ok")
        alert.show()
    }
    
    
    func newWishList(item: Item?) {
        if let item = item{
            wishlist.addItem(item)
            for t in wishlist.arr_wishlist{
                print(t.itemName)
            }
            print("new item is \(item.itemName)")
        }
        
    }
    
    
    func deleteItemWishlist(item : Item?){
        let delete_item = item?.itemName
        var counter = 0;
        for t in wishlist.arr_wishlist{
            if(t.itemName == delete_item){
                
                wishlist.arr_wishlist.remove(at: counter)
                showAlert(message: "Item deleted successfully")
                

            }
             counter = counter+1
        }
     
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
       addConstraint.constant -= view.bounds.width
        listConstraint.constant -= view.bounds.width
        
        searchConstraint.constant -= view.bounds.width
        
        deleteConstraint.constant -= view.bounds.width
      
    }
    var animationPerformedOnce = false
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if !animationPerformedOnce{
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
            self.addConstraint.constant += self.view.bounds.width
            self.view.layoutIfNeeded()
            
        }, completion: nil)
            
            UIView.animate(withDuration: 0.5, delay: 0.3, options: .curveEaseOut, animations: {
                self.listConstraint.constant += self.view.bounds.width
                self.view.layoutIfNeeded()
                
            }, completion: nil)
            
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.searchConstraint.constant += self.view.bounds.width
                self.view.layoutIfNeeded()
                
            }, completion: nil)
            
            UIView.animate(withDuration: 0.5, delay: 0.7, options: .curveEaseOut, animations: {
                self.deleteConstraint.constant += self.view.bounds.width
                self.view.layoutIfNeeded()
                
            }, completion: nil)
            
            animationPerformedOnce = true
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func add_btn(_ sender: UIButton) {
        performSegue(withIdentifier: "addSegue", sender: nil)
    }

   
    @IBAction func list_btn(_ sender: UIButton) {
        
        
        
      performSegue(withIdentifier: "listSegue", sender: nil)
        //present(listvc, animated: true, completion: nil)
        
        
    }
    
    
    @IBAction func search_btn(_ sender: UIButton) {
        performSegue(withIdentifier: "searchSegue", sender: nil)
    }
    @IBAction func delete_btn(_ sender: UIButton) {
        performSegue(withIdentifier: "deleteSegue", sender: self)
    }
}

