//
//  ItemType.swift
//  BuyApp
//
//  Created by Sheetal Singh on 10/13/17.
//  Copyright © 2017 NEU. All rights reserved.
//

import Foundation

class ItemType {
    var name: String = ""
    var arr_item: [Item] = []

    
    func addItem(_ item:Item){
        
         arr_item.append(item)
        
        }
        
    
        
    }
  







