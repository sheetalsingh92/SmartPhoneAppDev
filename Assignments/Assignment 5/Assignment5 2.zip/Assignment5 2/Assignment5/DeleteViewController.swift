//
//  DeleteViewController.swift
//  Assignment5
//
//  Created by Sheetal Singh on 10/26/17.
//  Copyright © 2017 Sheetal Singh. All rights reserved.
//

import UIKit
protocol deleteViewControllerDelegate: class{
    
    func deleteItemWishlist(item: Item?)
}
class DeleteViewController: UIViewController {

    var delegate: deleteViewControllerDelegate?
    
    @IBOutlet weak var item_name: UITextField!
    
    var wishlist : [Item] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showAlert(message : String){
        let alert = UIAlertView()
        alert.title = "Alert"
        alert.message = message
        alert.addButton(withTitle: "Ok")
        alert.show()
    }
    
    @IBAction func delete_btn(_ sender: UIButton) {
        
        if (item_name.text == ""){
            showAlert(message: "Please enter Item Name")
        }
            
        else{
            
            if( wishlist.isEmpty)
            {
                showAlert(message: "wishlist is empty")
                item_name.text=""
            }
            else
            {
                
              
                var xAppears = false
                var nameitem = ""
                var priceitem = 0;
                var typeitem = ItemType()
                
                for item in wishlist{
                    if(item_name.text == item.itemName){
                        
                        xAppears = true
                        nameitem = item.itemName
                        priceitem = item.itemPrice
                        typeitem = item.type
                        
                        
                        let item = Item(itemName: nameitem, itemPrice: priceitem, type: typeitem)
                        
                        delegate?.deleteItemWishlist(item: item)
                        
                        item_name.text = ""
                        break
                    }
                    
                    
                    
                    
                }
                
                if (!(xAppears))
                {
                    showAlert(message: "The item is not found in wishlist");
                    item_name.text = ""
                }
                
            }
            
        }
        

    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
